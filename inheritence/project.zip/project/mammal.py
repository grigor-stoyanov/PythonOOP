from project.animal import Animal


class Mammal(Animal):
    def __inait__(self, name):
        super().__init__(name)
